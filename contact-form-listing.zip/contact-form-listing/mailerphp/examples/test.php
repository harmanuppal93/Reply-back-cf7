<?php

/**
 * This example shows making an SMTP connection with authentication.
 */

//SMTP needs accurate times, and the PHP time zone MUST be set
//This should be done in your php.ini, but this is how to do it if you don't have access to that

/*
date_default_timezone_set('Etc/UTC');

require '../PHPMailerAutoload.php';

//Create a new PHPMailer instance
$mail = new PHPMailer;
//Tell PHPMailer to use SMTP
$mail->isSMTP();
//Enable SMTP debugging
// 0 = off (for production use)
// 1 = client messages
// 2 = client and server messages
$mail->SMTPDebug = 2;
//Ask for HTML-friendly debug output
$mail->Debugoutput = 'html';
//Set the hostname of the mail server
$mail->Host = "smtp.gmail.com";
//Set the SMTP port number - likely to be 25, 465 or 587
$mail->Port = 465;
//Whether to use SMTP authentication
$mail->SMTPAuth = true;
//Username to use for SMTP authentication
$mail->Username = "gulshan.webchefz@gmail.com";
//Password to use for SMTP authentication
$mail->Password = "gulshan@webchefz";
//Set who the message is to be sent from
$mail->setFrom('from@conversionhut.com', 'First Last');
//Set an alternative reply-to address
$mail->addReplyTo('noreplyto@conversionhut.com', 'First Last');
//Set who the message is to be sent to
$mail->addAddress('whoto@conversionhut.com', 'John Doe');
//Set the subject line
$mail->Subject = 'PHPMailer SMTP test';
//Read an HTML message body from an external file, convert referenced images to embedded,
//convert HTML into a basic plain-text alternative body
$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
//Replace the plain text body with one created manually
$mail->AltBody = 'This is a plain-text message body';
//Attach an image file
$mail->addAttachment('images/phpmailer_mini.png');

//send the message, check for errors
if (!$mail->send()) {
    echo "Mailer Error: " . $mail->ErrorInfo;
} else {
    echo "Message sent!";
}

*/


// 2nd 

/**
 * This example shows sending a message using a local sendmail binary.
 */
// print_r( $_POST );

if(isset($_POST['submit'])){


	$name = $_POST['name'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$pieces = $_POST['pieces'];
	$weight = $_POST['weight'];
	$description = $_POST['description'];
	$collpoint = $_POST['collpoint'];
	$delpoint = $_POST['delpoint'];



		require '../PHPMailerAutoload.php';

		//Create a new PHPMailer instance
		$mail = new PHPMailer;
		// Set PHPMailer to use the sendmail transport
		$mail->isSendmail();
		//Set who the message is to be sent from
		$mail->setFrom('from@conversionhut.com', 'First Last');
		//Set an alternative reply-to address
		$mail->addReplyTo('replyto@conversionhut.com', 'First Last');
		//Set who the message is to be sent to
		$mail->addAddress('gulshan.webchefz@gmail.com', 'John Doe');
		//Set the subject line
		$mail->Subject = 'Request Quote !!';
		//Read an HTML message body from an external file, convert referenced images to embedded,
		//convert HTML into a basic plain-text alternative body
		// $mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));



		$mail->msgHTML('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <title>Request Quote</title>
</head>
<body>
<div style="width: 640px; font-family: Arial, Helvetica, sans-serif; font-size: 11px;">
   <p><strong>Instant Quote Request Form Details</strong></p>
			<p></p>
			<p><strong>Name : </strong> '.$_POST['name'].'</p>
			<p><strong>Telephone : </strong> '.$_POST['phone'].'</p>
			<p><strong>Email : </strong> '.$_POST['email'].'</p>	
			<p><strong>Pieces : </strong> '.$_POST['pieces'].'</p>
			<p><strong>Weight : </strong> '.$_POST['weight'].'</p>
			<p><strong>Description : </strong> '.$_POST['description'].'</p>	
			<p><strong>Collpoint : </strong> '.$_POST['collpoint'].'</p>
			<p><strong>Delpoint : </strong> '.$_POST['delpoint'].'</p>
			<p></p>
		This e-mail was sent from a Instant Quote Request form on EFS Logistics
</div>
</body>
</html>');

		//Replace the plain text body with one created manually
		$mail->AltBody = 'This is a plain-text message body';
		//Attach an image file
		// $mail->addAttachment('images/phpmailer_mini.png');

		//send the message, check for errors
		if (!$mail->send()) {
		   echo '<script type="text/javascript">

		    	window.location.href="http://www.conversionhut.com/clients/efs-group/ajaxform.php";

		    </script>';
		} else {
		    // echo "Message sent!";

		    echo '<script type="text/javascript">

		    	window.location.href="http://www.conversionhut.com/clients/efs-group/ajaxform.php?message=true";

		    </script>';
		}
	
}