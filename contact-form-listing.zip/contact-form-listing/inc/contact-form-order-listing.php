<!DOCTYPE html>
<html lang="en">
<head>
  <title>Tennis contact list</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php 

  defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
  global $wpdb;
  global $wp_query;
	session_start();

      if(isset($_REQUEST['success']) && $_REQUEST['success'] == 1 && isset($_SESSION['wbc_message']) && $_SESSION['wbc_message'] == true) 
	  {
		  ?>
		  <script>$(document).ready(function() {
			  $(".container").before('<div id="message" class="notice notice-success is-dismissible"><p>Email sent.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
		  });
		  </script>
		  <?php
	  }
	  
	  if(isset($_REQUEST['error']) && $_REQUEST['error'] == 1 && isset($_SESSION['wbc_message']) && $_SESSION['wbc_message'] == true) 
	  {
		  ?>
		  <script>$(document).ready(function() {
			  $(".container").before('<div id="message" class="notice notice-error is-dismissible"><p>Unable to sent email.</p><button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>');
		  });
		  </script>
		  <?php
	  }
	  
	  $_SESSION['wbc_message'] = false;
	  
	  
	  

?>

<div class="wrap">
    <h2>Contact list</h2>

    <div class="container">
  
	<?php
	$args = array('post_type' => 'wpcf7_contact_form', 'posts_per_page' => -1 ,'orderby'  => 'title', 'order'    => 'ASC'); $contact_forms = get_posts($args);
	
	
	$querystr = "SELECT * FROM wp_cf7_vdata_entry ORDER BY ID DESC";
	$contact_list = $wpdb->get_results($querystr , ARRAY_A );
	
	
	$final_contacts = [];
	foreach($contact_list as $key => $value)
	{
		$final_contact[$value['cf7_id']][$value['data_id']][$value['name']] = $value['value'];
	}
	
	

	?>
  <ul class="nav nav-tabs">
  
  <?php
  $count = 0;
	if($contact_forms)
	{
		foreach ($contact_forms as $contact_form)
		{
			if($count == 0)			
				$active_class = "active";
			else
				$active_class = "";
			
			echo '<li class="'.$active_class.'"><a data-toggle="tab" href="#menu-'.$contact_form->ID.'">'.$contact_form->post_title.'</a></li>';
			$count++;
		}
	}
  ?>
    
   
  </ul>

  <div class="tab-content">  
  
  <?php
  $count = 0;
	if($contact_forms)
	{
		foreach ($contact_forms as $contact_form)
		{
			if($count == 0)			
				$active_class = "active";
			else
				$active_class = "";
			
			echo '<div id="menu-'.$contact_form->ID.'" class="tab-pane fade in '.$active_class.'">';
			
			if(current($final_contact[$contact_form->ID]))
			{
				?>
				<table id="allcontact-<?php echo $contact_form->ID; ?>" class="display" width="100%" cellspacing="0">
					
					<thead><tr>
					<th>Reply</th>
				<?php
				foreach(current($final_contact[$contact_form->ID]) as $key => $value)
				{
					
						if($key == "text-241")
							$key = "Name";
						
						if($key == "menu-459")
							$key = "Location";
						
						if($key == "menu-101")
							$key = "Type Of Classes";
						
						if($key == "email-264")
							$key = "Email";
						
						if($key == "tel-799")
							$key = "Phone";
						
						if($key == "text-510")
							$key = "Prefer time";
						
						
						echo "<th>$key</th>";
					
					
				}
				echo "</tr></thead><tfoot><tr><th>&nbsp;</th>";
				
				foreach(current($final_contact[$contact_form->ID]) as $key => $value)
				{
					
						if($key == "text-241")
							$key = "Name";
						
						if($key == "menu-459")
							$key = "Location";
						
						if($key == "menu-101")
							$key = "Type Of Classes";
						
						if($key == "email-264")
							$key = "Email";
						
						if($key == "tel-799")
							$key = "Phone";
						
						if($key == "text-510")
							$key = "Prefer time";
						
						echo "<th>$key</th>";
					
				}
				echo "</tr></tfoot>";				
				echo "<tbody>";
				
				foreach($final_contact[$contact_form->ID] as $key => $data)
				{					
					echo "<tr><td><button class='btn btn-primary' data-toggle='modal' data-target='#myModal-$contact_form->ID-$key'>Reply</button></td>";
					
					$email        = $data['email-264'];
					$contact_name = $data['text-241'];
					
					
					foreach($data as $details)
					{	
						
						echo "<td>$details</td>";
						
						
					}
					
					
					
					
					?>
					<!-- Modal -->
					<div class="modal fade" id="myModal-<?php echo $contact_form->ID."-".$key; ?>" role="dialog">
						<div class="modal-dialog">
						<!-- Modal content-->
							<div class="modal-content">
							<form action="<?php echo site_url(); ?>/wp-admin/admin-ajax.php?action=create_contact_payment" method="POST">
								<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal">&times;</button>
									<h4 class="modal-title">Lesson payment</h4>
								</div>
								<div class="modal-body">									
									<label>Amount:</label><br>
									<input type="text" required name="amount" class="form-control" placeholder="Amount"/>
									<br>
									<label>Additional Message</label><br>
<textarea name="message" rows="8" cols="20" class="form-control">Hi {username}
Please proceed with payment to start classes.
Payment page link : {payment_link}
Thanks

</textarea>
									<input type="hidden" name="CF7_id" value="<?php echo $contact_form->ID; ?>">
									<input type="hidden" name="CF7_name" value="<?php echo $contact_form->post_title; ?>">
									<input type="hidden" name="contact_id" value="<?php echo $key; ?>">
									<input type="hidden" name="contact_email" value="<?php echo $email; ?>">
									<input type="hidden" name="contact_name" value="<?php echo $contact_name; ?>">
								</div>
								<div class="modal-footer">									
									<button type="submit" class="btn btn-primary">Submit</button>
									<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								</div>
							</form>
							</div>

						</div>
					</div>
					<?php
					echo "</tr>";
				}
				
				?>
				</tbody>
				</table>
		
				<script type="text/javascript">
				$(document).ready(function() {
					$('#allcontact-<?php echo $contact_form->ID; ?>').DataTable( {
						"pagingType": "full_numbers"
					} );
				});
				</script>
				<?php
			}
			echo '</div>';
			$count++;
		}
	}
  ?>
  
    
		<?php
		/* $users =  dirname(__FILE__)."/users.php";
			include_once( $users );  */
		?>

    
    

    
  </div>
</div>

   
     
   
</div>

