<!DOCTYPE html>
<html lang="en">
<head>
  <title>Tennis payment list</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<?php 

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );
global $wpdb;
global $wp_query;
	
$querystr = "SELECT * FROM wp_lesson_payments ORDER BY ID DESC";
$contact_list = $wpdb->get_results($querystr , ARRAY_A );


?>

<div class="wrap">
    <h2>Contact list</h2>

    <div class="container">
  
	
  <ul class="nav nav-tabs">
  
  <li class="active"><a data-toggle="tab" href="#menu">Lesson Payments</a></li>
    
   
  </ul>

  <div class="tab-content">  
  <div id="menu" class="tab-pane fade in active">
 
		<h2>Lesson Payments List</h2>
		
		<table id="allpayments" class="display" width="100%" cellspacing="0">
					
			<thead><tr><th>Form Name</th><th>User email</th><th>Amount</th><th>Payment status</th></tr></thead>
			<tbody>
			<?php
			foreach($contact_list as $key => $value)
			{
				echo "<tr><td>".$value['CF7_name']."</td><td>".$value['contact_email']."</td><td>".$value['amount']."</td><td>".$value['payment_status']."</td></tr>";
			}
			
			?>
			
			</tbody>
			<tfoot><tr><th>CF7 Name</th><th>User email</th><th>Amount</th><th>Payment status</th></tr></tfoot>
		</table>
    
  </div>
</div>

   
     
   
</div>
<script type="text/javascript">
$(document).ready(function() {
	$('#allpayments').DataTable( {
		"pagingType": "full_numbers"
	} );
});
</script>
